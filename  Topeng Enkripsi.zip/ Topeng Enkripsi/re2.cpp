#include <iostream>
#include <string>

using namespace std;


// Disamarkan dengan XOR key 0x42
int encoded_flag[] = {
    0x01, 0x16, 0x04, 0x11, 0x0F, 0x09, 0x0C, 0x7A,
    0x39, 0x31, 0x36, 0x30, 0x73, 0x2C, 0x25, 0x1D,
    0x72, 0x20, 0x24, 0x37, 0x31, 0x21, 0x76, 0x36,
    0x73, 0x72, 0x2C, 0x3F,
    0x00
};

string decode_flag(int key) {
    string result = "";
    for (int i = 0; encoded_flag[i] != 0; i++) {
        result += (char)(encoded_flag[i] ^ key);
    }
    return result;
}

int main() {
    cout << "=== String Obfuscation ===" << endl;
    cout << "Tebak kunci XOR untuk decode flag!" << endl;

    cout << "Masukkan kunci : ";
    int key;
    cin >> hex >> key;

    string decoded = decode_flag(key);
    cout << "Hasil: " << decoded << endl;

    if (decoded == "CTFSMKN8{str1ng_0bfusc4t10n}") {
        cout << "✅ Benar!" << endl;
        cout << "Flag: " << decoded << endl;
    }

    return 0;
}
