#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;


int flag_codes[] = {
    0x60,0x77,0x65,0x70,0x6e,0x68,0x6d,0x1b,
    0x58,0x56,0x50,0x10,0x7c,0x17,0x45,0x57,
    0x10,0x51,0x7c,0x45,0x51,0x10,0x10,0x7c,
    0x47,0x17,0x4d,0x44,0x10,0x51,0x5e,0x00
};

char* decode_flag() {
    static char decoded[64];
    for (int i = 0; flag_codes[i] != 0; i++) {
        decoded[i] = flag_codes[i] ^ 0x23;
    }
    return decoded;
}

class User {
public:
    char name[24];

    virtual void greet() {
        cout << "Halo " << name << endl;
    }
};

class Admin : public User {
public:
    virtual void greet() {
        cout << "🎉 ADMIN ACCESS!" << endl;
        cout << "Flag: " << decode_flag() << endl;
    }
};

User* create_user() {
    User* u = new User();
    strcpy(u->name, "Guest");
    return u;
}

int main() {

    setbuf(stdout,NULL);
    setbuf(stdin,NULL);

    cout << "=== Heap Use After Free ===" << endl;

    User* user = create_user();

    user->greet();

    delete user;

    cout << "Input data: ";

    char* buf = (char*)malloc(sizeof(User));

    cin.read(buf, sizeof(User));

    cout << "Calling greet..." << endl;

    user->greet();

    return 0;
}
