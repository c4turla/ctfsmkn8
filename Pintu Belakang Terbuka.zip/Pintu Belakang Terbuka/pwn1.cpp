#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;

// Data terenkripsi (XOR 0x5A) 
unsigned char data_bin[] = {
    0x19, 0x0E, 0x1C, 0x09, 0x17, 0x11, 0x14, 0x62, 
    0x21, 0x38, 0x2F, 0x3C, 0x3C, 0x69, 0x28, 0x05, 
    0x6A, 0x2C, 0x69, 0x28, 0x3C, 0x36, 0x6A, 0x2D, 
    0x05, 0x38, 0x6E, 0x29, 0x6B, 0x39, 0x27, 0x00
};

void internal_output() {
    cout << "Flag: ";
    for (int i = 0; data_bin[i] != 0; i++) {
        char c = (char)(data_bin[i] ^ 0x5A);
        cout << c;
    }
    cout << endl;
}

void win() {
    cout << "\n🎉 BERHASIL! Kamu mendapatkan akses!" << endl;
    internal_output();
}

void vulnerable() {
    char buffer[32];
    cout << "=== Buffer Overflow Challenge ===" << endl;
    cout << "Masukkan input kamu: ";
    // Kerentanan utama: cin tidak membatasi jumlah input ke buffer[32]
    cin >> buffer; 
    cout << "Input diterima: " << buffer << endl;
}

int main() {
    // Mematikan buffering agar output langsung terlihat
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    
    vulnerable();
    return 0;
}
