<?php
session_start();
if (!isset($_COOKIE['flag'])) {
    setcookie('flag', 'CTFSMKN8{xss_cookie_stealer_master}', time() + 3600, '/');
}
$search = $_GET['q'] ?? '';
$message = '';
if ($search) {
    $message = "<div class='flag-box'>Search results for: " . $search . "</div>";
}
?>
<?php include '../includes/header.php'; ?>
<div class="container wide">
    <div class="nav">
        <a href="/ch1/">🏠 Home</a> <a href="/ch2/">📂 LFI</a> <a href="/ch3/">🌪️ SSTI</a> <a href="/ch4/">🔐 JWT</a>
    </div>
    <h1>🔍 Challenge 1: XSS Cookie Stealer</h1>
    <h2>Reflected Cross-Site Scripting</h2>
    <p>Your goal is to steal the flag stored in the cookie.</p>
    <form method="GET">
        <input type="text" name="q" placeholder="Search something..." value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit">🔎 Search</button>
    </form>
    <?php echo $message; ?>
    <div class="hint"><strong>💡 Hint:</strong> No Hint.</div>
</div>
<?php include '../includes/footer.php'; ?>