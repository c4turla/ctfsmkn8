<?php
session_start();
function base64url_encode($data) { return rtrim(strtr(base64_encode($data), '+/', '-_'), '='); }
function base64url_decode($data) { return base64_decode(strtr($data, '-_', '+/')); }
function create_jwt($payload, $secret = 'supersecretkey123') {
    $header = base64url_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $payload_encoded = base64url_encode(json_encode($payload));
    $signature = base64url_encode(hash_hmac('sha256', "$header.$payload_encoded", $secret, true));
    return "$header.$payload_encoded.$signature";
}
function verify_jwt($token, $secret = 'supersecretkey123') {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return false;
    $header = json_decode(base64url_decode($parts[0]), true);
    if (isset($header['alg']) && strtolower($header['alg']) === 'none') {
        return json_decode(base64url_decode($parts[1]), true);
    }
    $signature = hash_hmac('sha256', "$parts[0].$parts[1]", $secret, true);
    if (base64url_encode($signature) !== $parts[2]) return false;
    return json_decode(base64url_decode($parts[1]), true);
}
$flag = "CTFSMKN8{jwt_algorithm_none_bypass}";
$current_token = $_COOKIE['auth_token'] ?? '';
if (isset($_POST['username'])) {
    $payload = ['username' => $_POST['username'], 'role' => 'user', 'exp' => time() + 3600];
    $token = create_jwt($payload);
    setcookie('auth_token', $token, time() + 3600, '/');
    $current_token = $token;
}
if (isset($_GET['logout'])) {
    setcookie('auth_token', '', time() - 3600, '/');
    header('Location: /ch4/'); exit;
}
$user_data = $current_token ? verify_jwt($current_token) : null;
?>
<?php include '../includes/header.php'; ?>
<div class="container">
    <div class="nav">
        <a href="/ch1/">🏠 Home</a> <a href="/ch2/">📂 LFI</a> <a href="/ch3/">🌪️ SSTI</a> <a href="/ch4/">🔐 JWT</a>
    </div>
    <h1>🔐 Challenge 4: JWT Authentication</h1>
    <?php if($user_data): ?>
        <div class="flag-box" style="background: #d1fae5; border-color: #10b981; color: #065f46;">
            <strong>👤 Logged in as:</strong> <?php echo htmlspecialchars($user_data['username']); ?><br>
            <strong>🎭 Role:</strong> <?php echo htmlspecialchars($user_data['role']); ?>
        </div>
        <?php if($user_data['role'] === 'admin'): ?>
            <div class="flag-box">🎉 <strong>ADMIN ACCESS GRANTED!</strong><br>Flag: <?php echo $flag; ?></div>
        <?php else: ?>
            <p>⚠️ You need <strong>admin</strong> privileges to see the flag!</p>
        <?php endif; ?>
        <div class="token-display"><strong>Your Token:</strong><br><?php echo htmlspecialchars($current_token); ?></div>
        <a href="?logout=1"><button style="background: var(--danger);">🚪 Logout</button></a>
    <?php else: ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <button type="submit">🔑 Login</button>
        </form>
    <?php endif; ?>
    <div class="hint"><strong>💡 Hint:</strong> Change algorithm to <code>none</code> and role to <code>admin</code>. Remove signature.</div>
</div>
<?php include '../includes/footer.php'; ?>