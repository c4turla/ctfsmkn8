<?php
$name = $_GET['name'] ?? '';
$output = '';
if ($name) {
    $template = "Hello $name";
    eval("\$output = \"\$template\";");
}
?>
<?php include '../includes/header.php'; ?>
<div class="container">
    <div class="nav">
        <a href="/ch1/">🏠 Home</a> <a href="/ch2/">📂 LFI</a> <a href="/ch3/">🌪️ SSTI</a> <a href="/ch4/">🔐 JWT</a>
    </div>
    <h1>🌪️ Challenge 3: Template Injection</h1>
    <form method="GET">
        <input type="text" name="name" placeholder="Your name..." value="<?php echo htmlspecialchars($name); ?>">
        <button type="submit">🎉 Greet Me</button>
    </form>
    <?php if($output): ?>
    <div class="flag-box" style="background: #d1fae5; border-color: #10b981; color: #065f46;"><?php echo $output; ?></div>
    <?php endif; ?>
    <div class="hint"><strong>💡 Hint:</strong> Break out of the string. Payload: <code>'; system('cat /var/www/html/flags/flag3.txt'); //</code></div>
</div>
<?php include '../includes/footer.php'; ?>