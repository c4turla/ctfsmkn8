<?php
if(isset($_GET['file'])){
    $file = $_GET['file'];
    if(strpos($file, 'flag') !== false || strpos($file, '..') !== false){
        die("<div class='container'><h1>🚫 Access Denied!</h1></div>");
    }
    include($file);
    exit;
}
include '../includes/header.php';
?>
<div class="container wide">
    <div class="nav">
        <a href="/ch1/">🏠 Home</a> <a href="/ch2/">📂 LFI</a> <a href="/ch3/">🌪️ SSTI</a> <a href="/ch4/">🔐 JWT</a>
    </div>
    <h1>📂 Challenge 2: Local File Inclusion</h1>
    <h2>Log Poisoning Attack</h2>
    <div style="display: flex; gap: 10px; justify-content: center; margin: 20px 0;">
        <a href="?file=home.php"><button style="width: auto;">🏠 Home Page</button></a>
        <a href="?file=about.php"><button style="width: auto;">ℹ️ About Page</button></a>
    </div>
    <div class="hint"><strong>💡 Hint:</strong> Check the server logs (<code>/var/log/apache2/access.log</code>). You can write PHP code there via User-Agent!</div>
</div>
<?php include '../includes/footer.php'; ?>