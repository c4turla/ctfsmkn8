<!-- about.php -->
<div style="padding:20px;"><h2>ℹ️ About Us</h2><p>This CTF was created for educational purposes.</p></div>