<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CTF Web Challenge</title>
    <style>
        :root { --primary: #6366f1; --secondary: #4f46e5; --bg: #f3f4f6; --card-bg: #ffffff; --text: #1f2937; --danger: #ef4444; --success: #10b981; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; color: var(--text); }
        .container { background: var(--card-bg); border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); padding: 40px; width: 100%; max-width: 500px; text-align: center; }
        .container.wide { max-width: 800px; }
        h1 { color: var(--primary); margin-bottom: 10px; font-size: 28px; }
        h2 { color: var(--secondary); margin-bottom: 20px; font-size: 20px; font-weight: 500; }
        p { margin-bottom: 20px; color: #6b7280; line-height: 1.6; }
        .flag-box { background: #fef3c7; border: 2px dashed #f59e0b; padding: 15px; border-radius: 8px; margin: 20px 0; font-family: monospace; color: #92400e; word-break: break-all; }
        input[type="text"], input[type="password"], textarea { width: 100%; padding: 12px 15px; margin: 10px 0; border: 2px solid #e5e7eb; border-radius: 8px; font-size: 16px; transition: border-color 0.3s; }
        input:focus, textarea:focus { outline: none; border-color: var(--primary); }
        button { width: 100%; padding: 12px; background: var(--primary); color: white; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; transition: background 0.3s; margin-top: 10px; }
        button:hover { background: var(--secondary); }
        .hint { margin-top: 20px; padding: 15px; background: #eff6ff; border-radius: 8px; font-size: 14px; color: #1e40af; text-align: left; }
        .token-display { background: #f9fafb; padding: 10px; border-radius: 6px; font-family: monospace; font-size: 12px; word-break: break-all; text-align: left; margin: 15px 0; border: 1px solid #e5e7eb; }
        .nav { margin-bottom: 20px; }
        .nav a { color: var(--primary); text-decoration: none; margin: 0 10px; font-weight: 500; }
        .nav a:hover { text-decoration: underline; }
    </style>
</head>
<body>