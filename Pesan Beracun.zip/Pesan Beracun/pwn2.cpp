#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

// Flag: 

char part1[] = {
    0x19, 0x0E, 0x1C, 0x09, 0x17, 0x11, 0x14, 0x62, 0x21, 0x00
};

char part2[] = {
    0x3C, 0x6A, 0x28, 0x37, 0x6E, 0x2E, 0x05, 0x29, 0x2E, 0x28, 0x6B, 0x34, 0x3D, 0x00
};

char part3[] = {
    0x05, 0x36, 0x69, 0x6E, 0x31, 0x27, 0x00
};

char* decode_part(char* part, int key) {
    static char decoded[64];
    int i;

    for (i = 0; part[i] != 0; i++) {
        decoded[i] = part[i] ^ key;
    }

    decoded[i] = '\0';
    return decoded;
}

void show_flag() {
    cout << "🎉 Flag Terungkap!" << endl;
    cout << "Flag: "
         << decode_part(part1, 0x5A)
         << decode_part(part2, 0x5A)
         << decode_part(part3, 0x5A)
         << endl;
}

void vulnerable() {
    char input[100];

    cout << "=== Format String Challenge ===" << endl;
    cout << "Masukkan pesan: ";

    fgets(input, sizeof(input), stdin);
    input[strcspn(input, "\n")] = 0;

    cout << "Pesan kamu: ";
    printf(input);   // Format String Vulnerability
    cout << endl;
}

int main() {
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);

    vulnerable();

    return 0;
}
