#include <iostream>
#include <fstream>
#include <string>
#include <unistd.h>

using namespace std;

char encoded_flag[] = {
    0x19, 0x0E, 0x1C, 0x09, 0x17, 0x11, 0x14, 0x62,
    0x21, 0x6E, 0x34, 0x2E, 0x6B, 0x05, 0x3E, 0x69,
    0x38, 0x2F, 0x3D, 0x05, 0x2E, 0x28, 0x6B, 0x39,
    0x31, 0x27, 0x00
};

char* decode_flag() {
    static char decoded[64];
    for (int i = 0; encoded_flag[i] != 0; i++) {
        decoded[i] = encoded_flag[i] ^ 0x5A;
    }
    return decoded;
}

bool is_debugged() {
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/status", getpid());

    ifstream file(path);
    string line;
    while (getline(file, line)) {
        if (line.find("TracerPid") != string::npos) {
            if (line.find("0") == string::npos) {
                return true;
            }
        }
    }
    return false;
}

int main() {
    cout << "=== Anti-Debug Challenge ===" << endl;

    if (is_debugged()) {
        cout << "🚫 Debugger terdeteksi! Program exit." << endl;
        return 1;
    }

    cout << "✅ Tidak ada debugger. Lanjut..." << endl;
    cout << "Masukkan kode akses: ";

    int code;
    cin >> code;

    if (code == 1337) {
        cout << "Flag: " << decode_flag() << endl;
    } else {
        cout << "Kode salah!" << endl;
    }

    return 0;
}
