#include <iostream>
#include <string>
#include <cstring>

using namespace std;

char encoded_flag[] = {
    0x19,0x0E,0x1C,0x09,0x17,0x11,0x14,0x62,
    0x21,0x28,0x69,0x2C,0x69,0x28,0x29,0x69,
    0x05,0x69,0x34,0x3D,0x6B,0x34,0x69,0x69,
    0x28,0x6B,0x34,0x3D,0x27,0x00
};

char* decode_flag() {
    static char decoded[64];

    int i;
    for (i = 0; encoded_flag[i] != 0; i++) {
        decoded[i] = encoded_flag[i] ^ 0x5A;
    }

    decoded[i] = '\0'; // null terminator
    return decoded;
}

// Hash sederhana untuk password
unsigned long hash_password(const string& input) {
    unsigned long hash = 5381;
    for (char c : input) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

int main() {
    cout << "=== Simple Crackme ===" << endl;
    cout << "Masukkan password: ";

    string input;
    cin >> input;

    if (input == "smkn8jaya") {
        cout << "Password Benar!" << endl;
        cout << "Flag: " << decode_flag() << endl;
    } else {
        cout << "Password Salah!" << endl;
    }

    return 0;
}
